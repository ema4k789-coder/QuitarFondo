# FondoPro — editor de imágenes

FondoPro es un editor web adaptable a escritorio y móvil. La edición manual se ejecuta localmente en el navegador; el borrador IA carga una librería y modelos remotos y necesita conexión a internet.

## Funciones
- Abrir imágenes locales compatibles con el navegador.
- Quitar fondo con IA.
- Retoque manual con pincel Borrar y Restaurar, y borrado por color en la zona tocada.
- Zoom de la vista previa con pellizco (dos dedos), rueda del ratón o los botones − / % / +; «Ajustar» devuelve el encuadre. La resolución de la imagen nunca cambia.
- Borrado de color por región conectada.
- Perfeccionar bordes: suavizar, contraer, expandir e invertir máscara.
- Fondos sólidos, transparente y degradados, con visibilidad independiente.
- Capas de imagen y texto; mostrar/ocultar, seleccionar texto, duplicarlo y cambiar el orden relativo. La posición y el tamaño del texto se ajustan desde el panel, nunca arrastrándolo sobre la imagen.
- Recorte centrado por proporciones 1:1, 4:3, 3:4 y 16:9, con restablecimiento del encuadre original.
- Deshacer/rehacer hasta ocho estados recientes.
- Exportación con nombre personalizado a PNG o JPG desde un diálogo propio (no usa `prompt`/`confirm`, que Android WebView no implementa).

## Probar el flujo en el navegador
```
python tests/make_sample_png.py            # genera tests/sample-600x400.png
python tests/make_sample_png.py 2400 1600  # genera la imagen grande
python -m http.server 8123                 # sirve la carpeta
```
Abre `http://127.0.0.1:8123/index.html`, y en la consola del navegador:
```
await (await fetch('tests/flow-test.js')).text().then(t => eval(t));
for (const etapa of ['abrir','pincel','color','texto','bordes','recorte','exportar','vista','ia','grande']) await __run(etapa);
__report();
```
Son 64 chequeos del flujo completo (herramientas apiladas, texto visible y colocado desde el panel, pellizco sin trazos fantasma, exportación sin marco de selección, deshacer/rehacer, recortes sucesivos y tiempos de respuesta). `python tests/validate-project.py` sigue validando IDs, sintaxis y la sincronización con `capacitor/www/`.

## Ejecutar como web app
Sirve la carpeta por HTTP/HTTPS y abre `index.html` desde Chrome/Edge. La eliminación por IA necesita internet para descargar la librería y los modelos.

## Crear APK con Capacitor
Se incluye configuración inicial en `capacitor/`. En un equipo con Node.js LTS y Android Studio:
1. Copia `index.html`, `styles.css`, `app.js` y `manifest.json` a `capacitor/www/`.
2. Abre una terminal dentro de `capacitor/` y ejecuta `npm install`.
3. Ejecuta `npx cap add android` (solo la primera vez), `npx cap sync android` y `npx cap open android`.
4. En Android Studio, usa **Build > Build APK(s)**.

## Notas importantes
- La IA remota no garantiza una cancelación computacional inmediata: «Descartar resultado IA» evita aplicar el resultado cuando termina, pero el cálculo remoto/local iniciado por la librería puede continuar un tiempo.
- Mientras la IA está en curso se bloquean temporalmente las herramientas que cambian el tamaño o la máscara completa (recorte, invertir, contraer/expandir, suavizar, restablecer máscara, deshacer/rehacer) y abrir otra imagen. El pincel y el borrado por color siguen disponibles: sus retoques se conservan cuando llega el resultado de la IA.
- La app limita las imágenes cargadas a 40 MB y las reduce a un máximo de 2200 px por lado / 6 megapíxeles para controlar memoria.
- La orientación EXIF depende del decodificador del navegador. HEIC/HEIF puede no estar soportado; en ese caso, convierte a JPG o PNG.
- Antes de distribuir, ejecuta las pruebas de regresión enumeradas en `TODO_MEJORAS.md` en Chrome de escritorio y Android. El flujo interactivo ya se validó en navegador (64 chequeos, sin errores en consola); lo que sigue pendiente es el pellizco real con dedos y la exportación en el teléfono.
