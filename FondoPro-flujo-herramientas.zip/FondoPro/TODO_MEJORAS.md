# FondoPro — auditoría y lista de mejoras

## Implementado en esta versión
- [x] Conservar la imagen original como fuente para el borrado/restauración por máscara.
- [x] Componer la imagen y el fondo en el orden correcto; la transparencia no debe ser tapada por el fondo.
- [x] Ejecutar la IA varias veces sin multiplicar la transparencia progresivamente.
- [x] Conservar los retoques manuales que difieren de la última máscara IA al volver a ejecutar IA; la operación queda en el historial.
- [x] Comprobar la versión del documento antes de aceptar un resultado asíncrono de IA y bloquear la carga de otra imagen durante el proceso.
- [x] Añadir una acción para descartar el resultado de IA en curso. Nota: la librería remota no expone aquí una cancelación computacional garantizada; se descarta el resultado cuando vuelve.
- [x] Borrado por color conectado a la región tocada, no todos los píxeles similares de la imagen.
- [x] Contraer/expandir la máscara incluyendo los bordes del lienzo.
- [x] Limitar deshacer/rehacer a ocho estados y almacenar máscaras de historial en alfa de 1 byte por píxel.
- [x] Reutilizar el lienzo temporal de composición.
- [x] Limitar imágenes de entrada a 40 MB y reducir imágenes a un máximo de 2200 px por lado / 6 megapíxeles para las herramientas de edición.
- [x] Mensaje claro si el formato no se puede decodificar, incluyendo HEIC/HEIF.
- [x] Renombrar «Restablecer imagen» a «Restablecer máscara».
- [x] Añadir visibilidad independiente para fondo, imagen y texto.
- [x] Permitir seleccionar texto desde la lista, moverlo arrastrando, editarlo, duplicarlo y cambiar el orden relativo de textos.
- [x] Hacer que cada gesto de pincel sea una sola acción deshacible.
- [x] Hacer que los cambios de suavizado y color personalizado se registren como una operación deshacible por gesto.
- [x] Restablecer el encuadre original sin depender de los ocho estados del historial; se conserva la máscara de base y se superponen los retoques de la región recortada.
- [x] Permitir elegir el nombre de exportación, validar el blob generado y elegir PNG/JPG explícitamente.
- [x] Añadir etiqueta de estado accesible para lectores de pantalla.

## Correcciones de esta pasada: flujo y herramientas apiladas sin bloqueos
- [x] **El aviso «Tu lienzo te espera» tapaba el lienzo**: se mostraba con `z-index` mayor que el canvas y nunca se ocultaba al abrir una imagen, así que el primer toque abría el selector de archivos en lugar de pintar. Ahora `render()` lo oculta según el estado cargado y el contenedor ignora punteros (solo el botón de subir los recibe).
- [x] **Pintar dejaba de redibujar todo en cada movimiento**: `render()` (composición + lista de capas + ajuste de tamaño) corría por cada `pointermove`. Se separó en `draw()` puro, agrupado con `requestAnimationFrame` (`scheduleDraw()`). Medido en 2200×1467: un trazo de 40 puntos pasó de ~607 ms a ~39 ms.
- [x] **Borrado por color**: el relleno por cola de 4 vecinos asignaba `Int32Array(ancho×alto)` (12 MB en 3,2 MP) y revisitaba píxeles. Ahora es un relleno por líneas sobre una máscara de tolerancia previa, con pila que crece solo hasta el frente. Medido: 441 ms → 184 ms en 2200×1467 y 558 ms → 31 ms en 600×400. Además avisa si el toque queda fuera de tolerancia en vez de no hacer nada.
- [x] **Contraer/expandir borde**: filtro 3×3 con nueve lecturas por píxel vía closure → ahora es separable (dos pasadas de tres lecturas sobre el canal alfa), mismo resultado y ~300 ms → ~200 ms en 3,2 MP.
- [x] **Exportación inutilizable en Android**: usaba `prompt()` y `confirm()`, que WebView/Capacitor no implementan (devuelven `null` y la app no descargaba nada). Se reemplazó por un diálogo propio con nombre, PNG y JPG, botón deshabilitado y estado «Generando…», cierre con Escape o al tocar fuera.
- [x] **Herramientas apiladas sin ambigüedad**: se añadió la herramienta **Mover**. Antes el texto solo era arrastrable si la pestaña «Texto» estaba abierta, así que pintar cerca de un texto podía moverlo o no según el tab. Ahora el pincel siempre pinta y el texto se arrastra con Mover; al añadir un texto la herramienta Mover se activa sola.
- [x] **Choque de la IA con otras herramientas**: mientras la IA está en curso se bloquean recorte, invertir, contraer/expandir, suavizar, restablecer máscara, deshacer/rehacer y abrir otra imagen, con aviso claro. El pincel y el borrado por color siguen activos porque su trabajo se conserva al aplicar el resultado.
- [x] **Añadir texto sin imagen**: se impedía igual que en las demás herramientas; antes el texto se perdía en silencio al abrir la imagen después.
- [x] **Deshacer un recorte**: `restoreState()` limpiaba mal la referencia al encuadre base; ahora «Restablecer tamaño» no devuelve a un encuadre viejo.
- [x] **CSS roto**: la última regla de `styles.css` estaba escrita con literales `\n`, por lo que el bloque era inválido y se descartaba.
- [x] **Ayudas de la interfaz** actualizadas: la pestaña Pincel describe las cuatro herramientas y la pestaña Texto explica que Mover se activa al añadir.

## Validaciones ejecutadas
- [x] `node --check app.js` — sintaxis JavaScript válida.
- [x] Comprobación estática de HTML: sin IDs duplicados y sin referencias `$('#...')` a IDs inexistentes (`python tests/validate-project.py`).
- [x] Prueba interactiva en navegador: `tests/flow-test.js` ejecuta 47 chequeos del flujo (abrir, pincel borrar/restaurar, deshacer-rehacer, color, textos apilados, bordes de máscara, dos recortes y restablecer, exportación PNG/JPG, IA en curso e imagen de 3,2 MP) con marca de tiempo por operación. Todas pasan; cómo correrla en `README.md`.
- [x] Imágenes de prueba generadas por `tests/make_sample_png.py` (fondo magenta uniforme + círculo naranja) para verificar que el borrado por color solo toca la región conectada.
- [ ] Pruebas manuales en Chrome de escritorio y Android/Capacitor con un dispositivo real (la exportación por diálogo y los gestos multitoque deben verse en el teléfono).
- [ ] Validar la eliminación de fondo IA con conexión real, porque requiere descargar módulo y modelos remotos.

## Prueba de regresión antes de distribuir
1. Abrir un PNG con transparencia y un JPG opaco.
2. Aplicar IA; borrar y restaurar manualmente; ejecutar IA otra vez y confirmar que se conservan los retoques manuales.
3. Contraer, expandir, invertir y suavizar la máscara; deshacer/rehacer cada acción.
4. Borrar una región de color y verificar que otras zonas aisladas del mismo color no se borran.
5. Cambiar el fondo, ocultar/mostrar fondo e imagen y verificar que las capas se recuperan.
6. Añadir dos textos, seleccionar desde la lista, mover, editar, duplicar, reordenar, ocultar y eliminar.
7. Recortar dos veces, restablecer el encuadre original, y comprobar que se conserva el retoque de la zona visible.
8. Deshacer y rehacer alrededor de recortes y cambios de fondo.
9. Exportar PNG con transparencia y JPG con fondo; comprobar nombres, dimensiones y resultado.
10. Repetir en imágenes grandes y Android para detectar bloqueos o consumo excesivo de memoria.

> Alcance: se completaron las mejoras de código que pueden verificarse estáticamente. No se declara certificación de funcionamiento real hasta completar las pruebas de navegador y dispositivo indicadas arriba.
