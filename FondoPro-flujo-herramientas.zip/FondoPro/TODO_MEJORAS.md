# FondoPro — auditoría y lista de mejoras

## Implementado en esta versión
- [x] Conservar la imagen original como fuente para el borrado/restauración por máscara.
- [x] Componer la imagen y el fondo en el orden correcto; la transparencia no debe ser tapada por el fondo.
- [x] Ejecutar la IA varias veces sin multiplicar la transparencia progresivamente.
- [x] Conservar los retoques manuales que difieren de la última máscara IA al volver a ejecutar IA; la operación queda en el historial.
- [x] Comprobar la versión del documento antes de aceptar un resultado asíncrono de IA y bloquear la carga de otra imagen durante el proceso.
- [x] Añadir una acción para descartar el resultado de IA en curso. Nota: la librería remota no expone aquí una cancelación computacional garantizada; se descarta el resultado cuando vuelve.
- [x] Borrado por color conectado a la región tocada, no todos los píxeles similares de la imagen.
- [x] Contraer/expandir la máscara incluyendo los bordes del lienzo.
- [x] Limitar deshacer/rehacer a ocho estados y almacenar máscaras de historial en alfa de 1 byte por píxel.
- [x] Reutilizar el lienzo temporal de composición.
- [x] Limitar imágenes de entrada a 40 MB y reducir imágenes a un máximo de 2200 px por lado / 6 megapíxeles para las herramientas de edición.
- [x] Mensaje claro si el formato no se puede decodificar, incluyendo HEIC/HEIF.
- [x] Renombrar «Restablecer imagen» a «Restablecer máscara».
- [x] Añadir visibilidad independiente para fondo, imagen y texto.
- [x] Permitir seleccionar texto desde la lista, editarlo, duplicarlo y cambiar el orden relativo de textos (la posición y el tamaño se ajustan desde el panel, no arrastrando en el lienzo).
- [x] Hacer que cada gesto de pincel sea una sola acción deshacible.
- [x] Hacer que los cambios de suavizado y color personalizado se registren como una operación deshacible por gesto.
- [x] Restablecer el encuadre original sin depender de los ocho estados del historial; se conserva la máscara de base y se superponen los retoques de la región recortada.
- [x] Permitir elegir el nombre de exportación, validar el blob generado y elegir PNG/JPG explícitamente.
- [x] Añadir etiqueta de estado accesible para lectores de pantalla.

## Correcciones de esta pasada: flujo y herramientas apiladas sin bloqueos
- [x] **El aviso «Tu lienzo te espera» tapaba el lienzo**: se mostraba con `z-index` mayor que el canvas y nunca se ocultaba al abrir una imagen, así que el primer toque abría el selector de archivos en lugar de pintar. Ahora `render()` lo oculta según el estado cargado y el contenedor ignora punteros (solo el botón de subir los recibe).
- [x] **Pintar dejaba de redibujar todo en cada movimiento**: `render()` (composición + lista de capas + ajuste de tamaño) corría por cada `pointermove`. Se separó en `draw()` puro, agrupado con `requestAnimationFrame` (`scheduleDraw()`). Medido en 2200×1467: un trazo de 40 puntos pasó de ~607 ms a ~39 ms.
- [x] **Borrado por color**: el relleno por cola de 4 vecinos asignaba `Int32Array(ancho×alto)` (12 MB en 3,2 MP) y revisitaba píxeles. Ahora es un relleno por líneas sobre una máscara de tolerancia previa, con pila que crece solo hasta el frente. Medido: 441 ms → 184 ms en 2200×1467 y 558 ms → 31 ms en 600×400. Además avisa si el toque queda fuera de tolerancia en vez de no hacer nada.
- [x] **Contraer/expandir borde**: filtro 3×3 con nueve lecturas por píxel vía closure → ahora es separable (dos pasadas de tres lecturas sobre el canal alfa), mismo resultado y ~300 ms → ~200 ms en 3,2 MP.
- [x] **Exportación inutilizable en Android**: usaba `prompt()` y `confirm()`, que WebView/Capacitor no implementan (devuelven `null` y la app no descargaba nada). Se reemplazó por un diálogo propio con nombre, PNG y JPG, botón deshabilitado y estado «Generando…», cierre con Escape o al tocar fuera.
- [x] **Herramientas apiladas sin ambigüedad**: el pincel siempre pinta; el texto ya no se arrastra en el lienzo (ver la segunda pasada). Antes el texto solo era arrastrable si la pestaña «Texto» estaba abierta, así que pintar cerca de un texto podía moverlo o no según el tab.
- [x] **Choque de la IA con otras herramientas**: mientras la IA está en curso se bloquean recorte, invertir, contraer/expandir, suavizar, restablecer máscara, deshacer/rehacer y abrir otra imagen, con aviso claro. El pincel y el borrado por color siguen activos porque su trabajo se conserva al aplicar el resultado.
- [x] **Añadir texto sin imagen**: se impedía igual que en las demás herramientas; antes el texto se perdía en silencio al abrir la imagen después.
- [x] **Deshacer un recorte**: `restoreState()` limpiaba mal la referencia al encuadre base; ahora «Restablecer tamaño» no devuelve a un encuadre viejo.
- [x] **CSS roto**: la última regla de `styles.css` estaba escrita con literales `\n`, por lo que el bloque era inválido y se descartaba.
- [x] **Ayudas de la interfaz** actualizadas: la pestaña Pincel describe las tres herramientas y el pellizco; la pestaña Texto explica que el texto se maneja desde el panel.

## Correcciones de la segunda pasada: texto legible, zoom por pellizco y limpieza de adornos
- [x] **El texto no se veía**: el color por defecto era blanco y el lienzo arranca con fondo blanco, así que el texto recién escrito desaparecía sobre la zona clara. Ahora el color por defecto es oscuro (`#111827`) y al crear o editar un texto se mide la luminancia real de la zona que queda detrás (fondo + imagen ya retoada); si el contraste es insuficiente se elige automático el tono claro u oscuro visible y se avisa por toast. El cambio sigue siendo deshacible.
- [x] **El texto tenía borde**: se eliminó la sombra (`shadowColor`/`shadowBlur`) que se pintaba detrás de las letras. Además, el recuadro punteado de selección deja de dibujarse en el momento de exportar: `download()` anula la selección, redibuja y captura; se verificó que el PNG exportado no contiene ningún píxel del color del marco.
- [x] **El texto ya no se manipula en pantalla**: se quitó la herramienta **Mover** y todo el arrastre de capas de texto sobre el lienzo. La posición (X/Y en %) y el tamaño (% del alto del lienzo) se controlan desde el panel «Texto», que solo aparece con un texto seleccionado en la lista de Capas. Consecución directa: tocar la imagen no puede «cambiar de posición» ni arrastrar un texto, y un toque siempre hace lo que indica la herramienta activa.
- [x] **Pellizco para acercar**: dos dedos sobre la vista previa ajustan el zoom (100 %–800 %) y desplazan el lienzo sin cambiar la resolución de la imagen; al soltar un dedo se vuelve a pintar y no queda ningún punto suelto trazado por el segundo dedo (verificado píxel a píxel). Con un dedo se pinta; la rueda del ratón también acerca; los botones − / % / + y «Ajustar» viven en la barra inferior del escenario.
- [x] **Trazos fantasma con varios dedos**: el lienzo ahora registra cada `pointerId` por separado; solo el dedo que empezó el trazo pinta, un segundo dedo cancela el trazo y entra en pellizco, y `lostpointercapture` limpia el estado.
- [x] **El lienzo desbordaba el escenario**: `fitView()` corre al iniciar la app, así que el canvas se muestra ajustado desde el primer fotograma en lugar de su tamaño nativo de 900 px.
- [x] **Textos de adorno y publicidad fuera**: se eliminaron el encabezado «Tu imagen. Tu estilo.», las tarjetas de beneficios, el pie «Hecho para crear ✨», el eslogan «Tu creatividad, sin límites» y las explicaciones largas. El escenario empieza casi arriba y solo queda texto que describe una acción.
- [x] **CSS y JavaScript sin restos**: cayeron las reglas de `.intro`, `.spark`, `.tips` y `footer`, el selector huérfano del cuarto botón segmentado, y las variables `scaleX/scaleY` que ya no se usaban. La etiqueta de zoom vive en la barra inferior con su propio estilo.

## Validaciones ejecutadas
- [x] `node --check app.js` — sintaxis JavaScript válida.
- [x] Comprobación estática de HTML: sin IDs duplicados y sin referencias `$('#...')` a IDs inexistentes (`python tests/validate-project.py`).
- [x] Prueba interactiva en navegador: `tests/flow-test.js` ejecuta 64 chequeos del flujo (abrir, pincel borrar/restaurar, deshacer-rehacer, color, texto legible y colocado desde el panel, pellizco y controles de zoom, bordes de máscara, dos recortes y restablecer, exportación PNG/JPG sin marco de selección, IA en curso e imagen de 3,2 MP) con marca de tiempo por operación. Todas pasan; cómo correrla en `README.md`.
- [x] Tiempos medidos en la pasada final: gesto de pincel 9 ms, relleno por color 600×400 32 ms, contraer/expandir/invertir 18/32/8 ms, color en 2200×1467 181 ms, contraer en 2200×1467 195 ms, trazo en 2200×1467 28 ms.
- [x] Consola del navegador sin errores ni advertencias durante las 64 comprobaciones.
- [x] Imágenes de prueba generadas por `tests/make_sample_png.py` (fondo magenta uniforme + círculo naranja) para verificar que el borrado por color solo toca la región conectada.
- [ ] Pruebas manuales en Chrome de escritorio y Android/Capacitor con un dispositivo real (la exportación por diálogo y los gestos multitoque deben verse en el teléfono).
- [ ] Validar la eliminación de fondo IA con conexión real, porque requiere descargar módulo y modelos remotos.

## Prueba de regresión antes de distribuir
1. Abrir un PNG con transparencia y un JPG opaco.
2. Aplicar IA; borrar y restaurar manualmente; ejecutar IA otra vez y confirmar que se conservan los retoques manuales.
3. Contraer, expandir, invertir y suavizar la máscara; deshacer/rehacer cada acción.
4. Borrar una región de color y verificar que otras zonas aisladas del mismo color no se borran.
5. Cambiar el fondo, ocultar/mostrar fondo e imagen y verificar que las capas se recuperan.
6. Añadir dos textos, seleccionar desde la lista, cambiar posición y tamaño con los deslizadores, editar, duplicar, reordenar, ocultar y eliminar. Confirmar que el texto se ve sobre zonas claras y oscuras y que ningún toque en el lienzo lo mueve.
7. Pellizcar con dos dedos estando en Borrar: la vista acerca, no se pinta de más y al soltar se puede seguir pintando. Verificar − / + / «Ajustar» y la rueda del ratón.
8. Recortar dos veces, restablecer el encuadre original, y comprobar que se conserva el retoque de la zona visible.
9. Deshacer y rehacer alrededor de recortes y cambios de fondo.
10. Exportar PNG con transparencia y JPG con fondo; comprobar nombres, dimensiones, resultado y que el recuadro de selección no aparece en el archivo.
11. Repetir en imágenes grandes y Android para detectar bloqueos o consumo excesivo de memoria.

> Alcance: se completaron las mejoras de código que pueden verificarse estáticamente. No se declara certificación de funcionamiento real hasta completar las pruebas de navegador y dispositivo indicadas arriba.
