"""Validaciones estáticas de FondoPro. No reemplaza pruebas de interacción en navegador."""
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]

class IdParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if "id" in attrs:
            self.ids.append(attrs["id"])

for html_name, js_name in [("index.html", "app.js"), ("capacitor/www/index.html", "capacitor/www/app.js")]:
    html = (ROOT / html_name).read_text(encoding="utf-8")
    parser = IdParser()
    parser.feed(html)
    duplicates = [key for key, count in Counter(parser.ids).items() if count > 1]
    js = (ROOT / js_name).read_text(encoding="utf-8")
    refs = set(re.findall(r"\$\('#([^']+)'\)", js))
    missing = refs - set(parser.ids)
    if duplicates or missing:
        raise SystemExit(f"FAIL {html_name}: duplicate IDs={duplicates}; missing IDs={sorted(missing)}")
    result = subprocess.run(["node", "--check", str(ROOT / js_name)], capture_output=True, text=True)
    if result.returncode:
        raise SystemExit(f"FAIL syntax {js_name}: {result.stderr}")
    print(f"PASS {html_name}: {len(parser.ids)} unique IDs; {len(refs)} selectors; JavaScript syntax OK")

for name in ("index.html", "styles.css", "app.js", "manifest.json"):
    if (ROOT / name).read_bytes() != (ROOT / "capacitor/www" / name).read_bytes():
        raise SystemExit(f"FAIL web files differ between root and capacitor/www: {name}")
print("PASS web assets synchronized")
