"""Genera tests/sample.png: fondo magenta uniforme con un círculo naranja, útil para el borrado por color.

Uso: python tests/make_sample_png.py [ancho alto]  (por defecto 600 400)
"""
import struct
import sys
import zlib
from pathlib import Path

W = int(sys.argv[1]) if len(sys.argv) > 2 else 600
H = int(sys.argv[2]) if len(sys.argv) > 2 else 400
CIRCLE = (W // 2, H // 2, min(W, H) // 5)


def pixel(x, y):
    dx, dy = x - CIRCLE[0], y - CIRCLE[1]
    return (240, 120, 40) if dx * dx + dy * dy < CIRCLE[2] ** 2 else (255, 0, 255)


def chunk(kind, data):
    body = kind + data
    return struct.pack(">I", len(data)) + body + struct.pack(">I", zlib.crc32(body))


rows = b"".join(
    b"\x00" + b"".join(struct.pack("BBB", *pixel(x, y)) for x in range(W))
    for y in range(H)
)
png = (
    b"\x89PNG\r\n\x1a\n"
    + chunk(b"IHDR", struct.pack(">IIBBBBB", W, H, 8, 2, 0, 0, 0))
    + chunk(b"IDAT", zlib.compress(rows, 6))
    + chunk(b"IEND", b"")
)
target = Path(__file__).resolve().parent / f"sample-{W}x{H}.png"
target.write_bytes(png)
print(f"PASS {target.name}: {W}x{H}, {len(png)} bytes")
