/*
 * Regresión interactiva de FondoPro: flujo y herramientas apiladas sin bloqueos.
 * Uso desde la consola del navegador (o MCP evaluate_script):
 *   await (await fetch('tests/flow-test.js')).text().then(t => (0, eval)(t));
 *   await __run('abrir'); await __run('pincel'); ... ; __report()
 * Cada etapa devuelve sus chequeos; __report() resume todo y lista los fallos.
 */
(() => {
  const checks = [];
  const el = id => document.getElementById(id);
  const view = () => el('canvas');
  const add = (name, ok, detail) => { checks.push({ name, ok: !!ok, detail: detail === undefined ? '' : String(detail) }); return checks[checks.length - 1] };

  // Los PointerEvent sintéticos no tienen un pointer activo: se anula la captura para poder probar.
  Element.prototype.setPointerCapture = function () {};
  Element.prototype.releasePointerCapture = function () {};
  // En un viewport de 0x0 el lienzo se muestra a 24 px y el pincel se escala 25x; se fuerza 1:1
  // para que el test trabaje en píxeles de imagen reales.
  Object.defineProperty(HTMLCanvasElement.prototype, 'clientWidth', { configurable: true, get() { return this.width } });
  Object.defineProperty(HTMLCanvasElement.prototype, 'clientHeight', { configurable: true, get() { return this.height } });

  const realAnchorClick = HTMLAnchorElement.prototype.click;
  let promptsUsed = 0, downloads = [];
  window.prompt = () => { promptsUsed++; return null };
  window.confirm = () => { promptsUsed++; return true };
  HTMLAnchorElement.prototype.click = function () { downloads.push(this.download) };

  const clientPoint = (x, y) => { const r = view().getBoundingClientRect(); return { clientX: r.left + x * r.width / view().width, clientY: r.top + y * r.height / view().height } };
  const fire = (type, x, y) => {
    const p = clientPoint(x, y);
    view().dispatchEvent(new PointerEvent(type, Object.assign({ bubbles: true, cancelable: true, pointerId: 1, isPrimary: true, button: 0, buttons: type === 'pointerup' ? 0 : 1 }, p)));
  };
  const gesture = (path) => {
    fire('pointerdown', path[0][0], path[0][1]);
    for (let i = 1; i < path.length; i++) fire('pointermove', path[i][0], path[i][1]);
    fire('pointerup', path[path.length - 1][0], path[path.length - 1][1]);
  };
  const read = () => view().getContext('2d').getImageData(0, 0, view().width, view().height).data;
  const at = (px, x, y) => { const i = (Math.round(y) * view().width + Math.round(x)) * 4; return [px[i], px[i + 1], px[i + 2], px[i + 3]] };
  const near = (c, r, g, b, tol) => Math.abs(c[0] - r) <= tol && Math.abs(c[1] - g) <= tol && Math.abs(c[2] - b) <= tol;
  const paint = mode => { document.querySelector(`[data-mode="${mode}"]`).click(); return document.querySelector(`[data-mode="${mode}"]`).classList.contains('selected') };
  const setInput = (id, value) => { const n = el(id); n.value = String(value); n.dispatchEvent(new Event('input', { bubbles: true })); n.dispatchEvent(new Event('change', { bubbles: true })) };
  const toastBlocked = () => /Espera o descarta/.test(el('toast').textContent);
  const settle = (ms) => new Promise(r => setTimeout(r, ms));
  const load = async (path) => {
    const file = new File([(await (await fetch(path)).blob())], path.split('/').pop(), { type: 'image/png' });
    const dt = new DataTransfer(); dt.items.add(file);
    const input = el('fileInput'); input.files = dt.files;
    input.dispatchEvent(new Event('change', { bubbles: true }));
    await settle(250);
    return el('dimensions').textContent;
  };
  const inkCentroid = (px) => {
    let sx = 0, sy = 0, n = 0;
    for (let y = 0; y < view().height; y++) for (let x = 0; x < view().width; x++) {
      const c = at(px, x, y);
      if (c[3] > 200 && c[0] > 244 && c[1] > 244 && c[2] > 244) { sx += x; sy += y; n++ }
    }
    return { x: n ? sx / n : 0, y: n ? sy / n : 0, n };
  };
  const time = async (fn) => { const t0 = performance.now(); const r = fn(); await r; return Math.round(performance.now() - t0) };
  const state = {};

  const stages = {
    abrir: async () => {
      add('cargar imagen 600x400', (await load('tests/sample-600x400.png')) === '600 × 400 px', el('dimensions').textContent);
      add('el aviso de lienzo vacío deja de tapar el canvas', el('empty').classList.contains('hidden'), 'hidden=' + el('empty').classList.contains('hidden'));
      const px = read();
      add('el sujeto se ve antes de editar', near(at(px, 300, 200), 240, 120, 40, 26), at(px, 300, 200).join(','));
      add('el fondo propio de la imagen se ve', near(at(px, 20, 20), 255, 0, 255, 6), at(px, 20, 20).join(','));
    },
    pincel: async () => {
      setInput('brushSize', 40);
      add('herramienta Borrar activa', paint('erase'));
      state.eraseMs = await time(() => gesture([[300, 200], [320, 210], [340, 220]]));
      draw(); let px = read();
      add('borrar quita el sujeto', near(at(px, 320, 210), 255, 255, 255, 6), at(px, 320, 210).join(','));
      add('borrar respeta lo lejano', near(at(px, 250, 150), 240, 120, 40, 26), at(px, 250, 150).join(','));
      add('gesto de pincel no bloquea (<120ms)', state.eraseMs < 120, state.eraseMs + 'ms');
      add('herramienta Restaurar activa', paint('restore'));
      gesture([[320, 210], [300, 200]]); draw(); px = read();
      add('restaurar devuelve el sujeto', near(at(px, 310, 205), 240, 120, 40, 34), at(px, 310, 205).join(','));
      el('undoBtn').click(); draw(); px = read();
      state.undoPixel = at(px, 320, 210);
      add('deshacer revierte el último gesto', near(state.undoPixel, 255, 255, 255, 8), state.undoPixel.join(','));
      el('redoBtn').click(); draw(); px = read();
      add('rehacer recupera el gesto', near(at(px, 320, 210), 240, 120, 40, 40), at(px, 320, 210).join(','));
    },
    color: async () => {
      add('herramienta Color activa', paint('color'));
      setInput('tolerance', 45);
      state.colorMs = await time(() => { fire('pointerdown', 20, 20); fire('pointerup', 20, 20) });
      draw(); const px = read();
      add('el magenta contiguo se elimina', near(at(px, 400, 60), 255, 255, 255, 6), at(px, 400, 60).join(','));
      add('el sujeto sigue intacto tras el color', near(at(px, 300, 200), 240, 120, 40, 26), at(px, 300, 200).join(','));
      add('relleno de color 600x400 no bloquea (<200ms)', state.colorMs < 200, state.colorMs + 'ms');
    },
    texto: async () => {
      await load('tests/sample-600x400.png');
      document.querySelector('[data-bg="#111827"]').click();
      setInput('textValue', 'HOLA');
      el('addText').click(); draw();
      add('añadir texto activa la herramienta Mover', paint('move') && !document.querySelector('[data-mode="erase"]').classList.contains('selected'));
      add('el texto aparece en la lista de capas', /Texto: HOLA/.test(el('layerList').innerText), el('layerList').innerText.replace(/\n/g, ' | '));
      let px = read(); state.before = inkCentroid(px);
      add('el texto se dibuja en el lienzo', state.before.n > 60, JSON.stringify(state.before));
      gesture([[state.before.x, state.before.y], [state.before.x + 60, state.before.y + 40]]); draw(); px = read();
      const after = inkCentroid(px);
      add('Mover desplaza el texto arrastrando', after.x - state.before.x > 35 && after.y - state.before.y > 20, `${state.before.x.toFixed(0)},${state.before.y.toFixed(0)} -> ${after.x.toFixed(0)},${after.y.toFixed(0)}`);
      setInput('brushSize', 60); paint('erase');
      const anchor = inkCentroid(read());
      gesture([[anchor.x, anchor.y], [anchor.x, anchor.y + 45]]); draw(); px = read();
      state.underBrush = at(px, Math.round(anchor.x), Math.round(anchor.y + 43));
      add('el pincel borra la imagen aunque haya un texto encima', near(state.underBrush, 17, 24, 39, 26), state.underBrush.join(','));
      const moved = inkCentroid(px);
      add('pintar sobre un texto no lo arrastra', Math.abs(moved.x - anchor.x) < 6, `${moved.x.toFixed(0)} vs ${anchor.x.toFixed(0)}`);
    },
    bordes: async () => {
      state.contractMs = await time(() => el('contractMask').click());
      add('contraer borde no bloquea (<150ms)', state.contractMs < 150, state.contractMs + 'ms');
      state.expandMs = await time(() => el('expandMask').click());
      add('expandir borde no bloquea (<150ms)', state.expandMs < 150, state.expandMs + 'ms');
      state.invertMs = await time(() => el('invertMask').click());
      add('invertir selección no bloquea (<150ms)', state.invertMs < 150, state.invertMs + 'ms');
      setInput('feather', 3);
      add('suavizado aplicado', el('featherOut').value === '3 px', el('featherOut').value);
      el('resetMask').click(); draw();
      const px = read();
      add('restablecer máscara devuelve el sujeto', near(at(px, 300, 200), 240, 120, 40, 26), at(px, 300, 200).join(','));
    },
    recorte: async () => {
      document.querySelector('[data-ratio="0.75"]').click();
      const cropped = el('dimensions').textContent;
      document.querySelector('[data-ratio="1.7778"]').click();
      add('dos recortes seguidos cambian el encuadre', cropped !== el('dimensions').textContent, `${cropped} -> ${el('dimensions').textContent}`);
      el('resetCrop').click();
      add('restablecer devuelve el encuadre original', el('dimensions').textContent === '600 × 400 px', el('dimensions').textContent);
      draw(); const px = read();
      add('el sujeto sigue visible tras recortar y restablecer', near(at(px, 300, 200), 240, 120, 40, 26), at(px, 300, 200).join(','));
      el('undoBtn').click(); draw();
      add('deshacer un recorte no rompe el flujo', el('dimensions').textContent.length > 0, el('dimensions').textContent);
    },
    exportar: async () => {
      el('exportBtn').click();
      add('el diálogo de exportación abre', !el('exportSheet').classList.contains('hidden'));
      add('la exportación ya no usa prompt/confirm', promptsUsed === 0, 'usados=' + promptsUsed);
      setInput('exportName', 'mi-diseno');
      el('exportJpg').click();
      add('exportar deshabilita los botones mientras genera', el('exportJpg').disabled && /Generando JPG/.test(el('status').textContent), el('status').textContent);
      const got = async (re) => { for (let i = 0; i < 40; i++) { if (downloads.some(n => re.test(n))) return true; await settle(100) } return false };
      add('JPG descarga con el nombre escrito', await got(/\.jpg$/i) && downloads.some(n => /mi-diseno\.jpg$/i.test(n)), downloads.join(','));
      add('el diálogo se cierra al exportar', el('exportSheet').classList.contains('hidden'), 'hidden=' + el('exportSheet').classList.contains('hidden'));
      add('los botones vuelven a estar activos', el('exportJpg').disabled === false && el('exportPng').disabled === false, el('status').textContent);
      el('exportBtn').click(); el('exportPng').click();
      add('PNG descarga desde el diálogo', await got(/\.png$/i), downloads.join(','));
      HTMLAnchorElement.prototype.click = realAnchorClick;
    },
    ia: async () => {
      await load('tests/sample-600x400.png');
      const pending = autoRemove();
      add('la IA en curso deshabilita su botón', el('autoBtn').disabled === true, 'disabled=' + el('autoBtn').disabled);
      el('invertMask').click();
      add('con la IA en curso la máscara espera', toastBlocked(), el('toast').textContent);
      el('resetCrop').click();
      add('con la IA en curso el recorte espera', toastBlocked());
      el('undoBtn').click();
      add('con la IA en curso deshacer espera', toastBlocked());
      el('cancelAiBtn').click();
      await Promise.race([Promise.resolve(pending).catch(() => {}), settle(4000)]);
      el('contractMask').click();
      state.aiAfter = el('toast').textContent;
      add('las herramientas responden al terminar la IA', !toastBlocked(), state.aiAfter);
    },
    grande: async () => {
      state.bigDims = await load('tests/sample-2400x1600.png');
      add('la imagen grande se reduce por rendimiento', state.bigDims === '2200 × 1467 px', state.bigDims);
      paint('color'); setInput('tolerance', 45);
      state.bigColorMs = await time(() => { fire('pointerdown', 40, 40); fire('pointerup', 40, 40) });
      add('borrado por color 2200x1467 no congela (<900ms)', state.bigColorMs < 900, state.bigColorMs + 'ms');
      state.bigContractMs = await time(() => el('contractMask').click());
      add('contraer 2200x1467 no congela (<900ms)', state.bigContractMs < 900, state.bigContractMs + 'ms');
      paint('erase'); setInput('brushSize', 80);
      state.bigStrokeMs = await time(() => gesture([[1100, 733], [1160, 760], [1220, 790]]));
      add('pintar en grande no congela (<80ms por gesto)', state.bigStrokeMs < 80, state.bigStrokeMs + 'ms');
    }
  };

  window.__run = async name => { await stages[name](); return checks.filter(c => !c.ok).map(c => 'FAIL ' + c.name + ' :: ' + c.detail) };
  window.__report = () => ({ total: checks.length, failed: checks.filter(c => !c.ok).length, lines: checks.map(c => (c.ok ? 'OK   ' : 'FAIL ') + c.name + ' :: ' + c.detail) });
})();
